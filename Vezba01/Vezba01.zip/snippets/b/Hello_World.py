import sys

print("Hello World")

print("__name__ value:", __name__)