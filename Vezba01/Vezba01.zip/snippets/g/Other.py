import Hello_World

print("__name__ value:", __name__)

if __name__ == '__main__':
    print("Hello from executable module")
    Hello_World.myfoo("blah blah msg...")