import sys

print("__name__ value:", __name__)

print("Hello from module")


if __name__ == '__main__':
    print("Hello from executable module")